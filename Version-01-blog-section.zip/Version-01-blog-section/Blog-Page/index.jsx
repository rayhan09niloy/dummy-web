import React from "react";
import cardDiscoverBlog2 from "./card-discover-blog-2.svg";
import cardDiscoverBlog3 from "./card-discover-blog-3.svg";
import cardDiscoverBlog from "./card-discover-blog.svg";
import cardLetestBlog2 from "./card-letest-blog-2.svg";
import cardLetestBlog from "./card-letest-blog.svg";
import image from "./image.svg";
import navber from "./navber.svg";

export const Blogs = () => {
  return (
    <div className="relative w-[1440px] h-[1016px] bg-white [background:linear-gradient(180deg,rgb(12.9,23,49.94)_53.5%,rgb(9,15,31)_100%)]">
      <div className="flex flex-col w-[1240px] items-start gap-7 absolute top-[482px] left-[100px]">
        <div className="relative self-stretch mt-[-1.00px] font-h3 font-[number:var(--h3-font-weight)] text-white text-[length:var(--h3-font-size)] tracking-[var(--h3-letter-spacing)] leading-[var(--h3-line-height)] [font-style:var(--h3-font-style)]">
          Discover More
        </div>

        <div className="flex flex-wrap w-[1240px] items-start gap-[19px_20px] relative flex-[0_0_auto]">
          <img
            className="relative w-[610px]"
            alt="Card discover blog"
            src={cardDiscoverBlog}
          />

          <img
            className="relative w-[610px]"
            alt="Card discover blog"
            src={cardDiscoverBlog2}
          />

          <img
            className="relative w-[610px]"
            alt="Card discover blog"
            src={cardDiscoverBlog3}
          />
        </div>
      </div>

      <div className="flex flex-col w-[1240px] items-start gap-7 absolute top-44 left-[100px]">
        <div className="relative self-stretch mt-[-1.00px] font-h3 font-[number:var(--h3-font-weight)] text-white text-[length:var(--h3-font-size)] tracking-[var(--h3-letter-spacing)] leading-[var(--h3-line-height)] [font-style:var(--h3-font-style)]">
          Latest
        </div>

        <div className="flex w-[1240px] items-center gap-5 relative flex-[0_0_auto]">
          <img
            className="relative w-[400px]"
            alt="Card letest blog"
            src={cardLetestBlog}
          />

          <img
            className="relative w-[400px]"
            alt="Card letest blog"
            src={image}
          />

          <img
            className="relative w-[400px]"
            alt="Card letest blog"
            src={cardLetestBlog2}
          />
        </div>
      </div>

      <div className="flex flex-col w-[533px] items-center gap-3 absolute top-[912px] left-[453px]">
        <p className="relative self-stretch mt-[-1.00px] [font-family:'Open_Sans-SemiBold',Helvetica] font-semibold text-textnutral-100 text-2xl tracking-[0] leading-[normal]">
          Get started to learn, share and grow togather!
        </p>

        <p className="relative self-stretch [font-family:'Open_Sans-Regular',Helvetica] font-normal text-textnutrals-200 text-sm text-center tracking-[0] leading-[normal]">
          © 2024 MUPI Computer Club - Munshiganj Polytechnic Instiitute
        </p>
      </div>

      <img
        className="absolute w-[1240px] h-14 top-10 left-[100px]"
        alt="Navber"
        src={navber}
      />
    </div>
  );
};
