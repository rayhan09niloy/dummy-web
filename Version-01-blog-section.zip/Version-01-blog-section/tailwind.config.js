/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./src/**/*.{html,js,ts,jsx,tsx}"],
    theme: {
      extend: {
        colors: {
          "card-background": "var(--card-background)",
          "text-card-body": "var(--text-card-body)",
          "text-card-headline": "var(--text-card-headline)",
          "textnutral-100": "var(--textnutral-100)",
          "textnutrals-200": "var(--textnutrals-200)",
        },
        fontFamily: {
          "body-bodu-100": "var(--body-bodu-100-font-family)",
          "body-body-200": "var(--body-body-200-font-family)",
          h3: "var(--h3-font-family)",
          h5: "var(--h5-font-family)",
          "head-h4": "var(--head-h4-font-family)",
          "title-title-main": "var(--title-title-main-font-family)",
        },
      },
    },
    plugins: [],
  };
  